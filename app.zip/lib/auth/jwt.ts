// import jwt from "jsonwebtoken";

// export type AccessTokenPayload = {
//   sub: string; // user id
//   storeId: string;
//   role: "owner" | "manager" | "employee";
// };

// const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET ?? "dev-access-secret";
// const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET ?? "dev-refresh-secret";
// const ACCESS_EXPIRES_IN = process.env.JWT_ACCESS_EXPIRES_IN ?? "15m";
// const REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN ?? "30d";

// export function signAccessToken(payload: AccessTokenPayload) {
//   return jwt.sign(payload, ACCESS_SECRET, { expiresIn: ACCESS_EXPIRES_IN });
// }

// export function signRefreshToken(payload: { sub: string }) {
//   return jwt.sign(payload, REFRESH_SECRET, { expiresIn: REFRESH_EXPIRES_IN });
// }

// export function verifyAccessToken(token: string) {
//   return jwt.verify(token, ACCESS_SECRET) as AccessTokenPayload & jwt.JwtPayload;
// }

// export function verifyRefreshToken(token: string) {
//   return jwt.verify(token, REFRESH_SECRET) as { sub: string } & jwt.JwtPayload;
// }
import jwt, { type SignOptions, type JwtPayload } from "jsonwebtoken";

export type AccessTokenPayload = {
  sub: string; // user id
  storeId: string;
  role: "owner" | "manager" | "employee";
};

const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET ?? "dev-access-secret";
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET ?? "dev-refresh-secret";

// Short default kept for anyone relying on the old env var, but login/register
// now always pass an explicit expiry (1 day normally, 30 days with "Remember me"),
// so this fallback rarely matters in practice.
const ACCESS_EXPIRES_IN = (process.env.JWT_ACCESS_EXPIRES_IN ?? "1d") as SignOptions["expiresIn"];

const REFRESH_EXPIRES_IN = (process.env.JWT_REFRESH_EXPIRES_IN ?? "30d") as SignOptions["expiresIn"];

export function signAccessToken(payload: AccessTokenPayload, expiresIn: SignOptions["expiresIn"] = ACCESS_EXPIRES_IN): string {
  return jwt.sign(payload, ACCESS_SECRET, {
    expiresIn,
  });
}

export function signRefreshToken(payload: { sub: string }): string {
  return jwt.sign(payload, REFRESH_SECRET, {
    expiresIn: REFRESH_EXPIRES_IN,
  });
}

export function verifyAccessToken(
  token: string
): AccessTokenPayload & JwtPayload {
  return jwt.verify(token, ACCESS_SECRET) as AccessTokenPayload & JwtPayload;
}

export function verifyRefreshToken(
  token: string
): { sub: string } & JwtPayload {
  return jwt.verify(token, REFRESH_SECRET) as { sub: string } & JwtPayload;
}